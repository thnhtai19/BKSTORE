<footer class="bg- text-gray-700 p-4 border">
    <p>&copy; 2024 BKStore</p>
</footer>
